# Copyright 2021 Jason Bakos, Philip Conrad, Charles Daniels
#
# Distributed as part of the University of South Carolina CSCE317 course
# materials. Please do not redistribute without written authorization.

# This file is intentionally empty. It needs to be present so it can be
# imported from other Python files. It is used to store global variables
# utilized throughout the program, which are set in main.py.
