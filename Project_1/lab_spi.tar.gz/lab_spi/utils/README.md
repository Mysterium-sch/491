This directory contains utility libraries intended for students to use to
complete assignments.

Students are welcome and encouraged to read any of the code here, but should be
advised that a reference version will be used for grading purposes. In other
words, your submitted code must work with the original, unmodified versions of
these libraries.
